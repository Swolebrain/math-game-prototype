 font - Burning Wrath 
https://www.dafont.com/burning-wrath.font?l[]=10&l[]=1&text=ELEMENTAL